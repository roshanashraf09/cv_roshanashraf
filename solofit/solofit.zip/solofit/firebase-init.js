/* ============================================================
   PASTE YOUR FIREBASE CONFIG BELOW
   You got this from the Firebase Console in step 5.
   Replace the placeholder values with yours.
   ============================================================ */

const firebaseConfig = {
  apiKey: "PASTE_YOUR_API_KEY_HERE",
  authDomain: "PASTE_YOUR_PROJECT.firebaseapp.com",
  projectId: "PASTE_YOUR_PROJECT_ID",
  storageBucket: "PASTE_YOUR_PROJECT.appspot.com",
  messagingSenderId: "PASTE_YOUR_SENDER_ID",
  appId: "PASTE_YOUR_APP_ID"
};

/* ============================================================
   Don't change anything below this line
   ============================================================ */

firebase.initializeApp(firebaseConfig);
window.fbAuth = firebase.auth();
